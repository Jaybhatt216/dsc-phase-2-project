Business Problem
what affect home price increase based on Kings county housing data

Stake holders
Real estate organization that wishes to sell property or purchase property based on confidence that property will yield positive ROI

Conclusion
As shown by our model the grade and sqft_living affect price most closely. 
We can see a positive linear relationship between these factors and 
it is predicted by our current model that price will increase base on these values. 
Price may also be affected by these values having a lower grade or less sqft_living by reduce price

Future work
We can impliment various regression algorithms for this data to test, 
we can also test the inverse where we can show what is likely to reduce price. 
We can also impliment deep learning models or simple neural networks that will give us results based on past data. 
NOTE: all future work is based on time and funding and without appropriate amount of both niether will be possible. 
Future work also takes into account proper infrastructure is in place to build these things.

https://github.com/Jaybhatt216/dsc-phase-2-project/blob/my-sub/Kings_County_housing_data_regression_with%20feature_selection%20(1).ipynb